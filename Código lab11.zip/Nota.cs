﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E1_Herencia
{
    public class Nota
    {
        public string curso { get; set; }
        public int punteo { get; set; }

    }
}